<?php

namespace Bookie\Blockchain;

use Bookie\Blockchain\Exception\NetworkException;

interface BookieBetBlockChainInterface
{
    /**
     * Create contact in blockchain and return transaction hash.
     *
     * @param Bet $bet
     *
     * @return string
     *
     * @throws NetworkException
     */
    public function createBet(Bet $bet): string;

    /**
     * Request contract address by transaction hash. If exist return it, else null.
     *
     * @param string $transactionHash
     *
     * @return string|null
     *
     * @throws NetworkException
     */
    public function getContractAddress(string $transactionHash);

    /**
     * @param string $transactionHash
     *
     * @return ContractState
     *
     * @throws NetworkException
     */
    public function getContractState(string $transactionHash): ContractState;

    /**
     * @param string $contractAddress
     *
     * @return Bet
     *
     * @throws NetworkException
     */
    public function getBet(string $contractAddress);


    /**
     * todo return type
     *
     * @param string $contractAddress
     *
     * @param BetResult $result
     *
     * @throws NetworkException
     */
    public function settleBet(string $contractAddress, BetResult $result);

    /**
     * @param string $contractAddress
     *
     * @return BetResult
     *
     * @throws NetworkException
     */
    public function getBetResult(string $contractAddress): BetResult;

}