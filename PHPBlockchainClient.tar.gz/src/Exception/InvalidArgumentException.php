<?php

namespace Bookie\Blockchain\Exception;

class InvalidArgumentException extends \InvalidArgumentException
{
}