<?php

namespace Bookie\Blockchain\Exception;

class NetworkException extends \RuntimeException
{
}