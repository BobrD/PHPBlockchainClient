<?php

namespace Bookie\Blockchain;

class NullBetBlockchain implements BookieBetBlockChainInterface
{
    public function createBet(Bet $bet): string
    {
        return '123';
    }

    public function getContractAddress(string $transactionHash)
    {
        return null;
    }

    public function getContractState(string $transactionHash): ContractState
    {
        return ContractState::create(ContractState::PENDING);
    }


    public function getBet(string $contractAddress)
    {
        throw new \RuntimeException('not implemented');
    }

    public function settleBet(string $contractAddress, BetResult $result)
    {

    }

    public function getBetResult(string $contractAddress): BetResult
    {
        throw new \RuntimeException('not implemented');
    }
}